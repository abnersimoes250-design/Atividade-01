﻿using System;

namespace AplicativoBanco
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("===== TESTE DAS CONTAS =====\n");

            var conta1 = new ContaBancaria("Julie Caroline", "12345", "001", 2400);
            conta1.Depositar(200);
            conta1.Sacar(100);

            Console.WriteLine("Conta Bancária:");
            Console.WriteLine($"Cliente: {conta1.NomeCliente}");
            Console.WriteLine($"Saldo: {conta1.Saldo}\n");

            var poup = new ContaPoupanca("Anne Caroline", "77777", "002", 200, 25, 0.02);
            poup.CalcularNovoSaldo(25);

            Console.WriteLine("Conta Poupança:");
            Console.WriteLine($"Cliente: {poup.NomeCliente}");
            Console.WriteLine($"Saldo atualizado: {poup.Saldo}\n");

            var especial = new ContaEspecial("Anna Julia", "99999", "003", 2016, 500);
            especial.Sacar(700); 

            Console.WriteLine("Conta Especial:");
            Console.WriteLine($"Cliente: {especial.NomeCliente}");
            Console.WriteLine($"Saldo após saque com limite: {especial.Saldo}");
        }
    }
}
