﻿namespace AplicativoBanco
{
    public class ContaBancaria
    {
        public string NomeCliente { get; set; }
        public string NumeroConta { get; set; }
        public string Agencia { get; set; }
        public double Saldo { get; protected set; }

        public ContaBancaria() { }

        public ContaBancaria(string nomeCliente, string numeroConta, string agencia, double saldoInicial)
        {
            NomeCliente = nomeCliente;
            NumeroConta = numeroConta;
            Agencia = agencia;
            Saldo = saldoInicial;
        }

        public virtual bool Sacar(double valor)
        {
            if (valor <= 0) return false;

            if (Saldo - valor < 0)
                return false;

            Saldo -= valor;
            return true;
        }

        public void Depositar(double valor)
        {
            if (valor > 0)
                Saldo += valor;
        }
    }
}
