﻿namespace AplicativoBanco
{
    public class ContaPoupanca : ContaBancaria
    {
        public int DiaDeRendimento { get; set; }
        public double TaxaDeRendimento { get; set; }

        public ContaPoupanca() { }

        public ContaPoupanca(string nome, string conta, string agencia, double saldo, int dia, double taxa)
            : base(nome, conta, agencia, saldo)
        {
            DiaDeRendimento = dia;
            TaxaDeRendimento = taxa;
        }

        public void CalcularNovoSaldo(int diaAtual)
        {
            if (diaAtual == DiaDeRendimento)
            {
                Saldo += Saldo * TaxaDeRendimento;
            }
        }
    }
}
