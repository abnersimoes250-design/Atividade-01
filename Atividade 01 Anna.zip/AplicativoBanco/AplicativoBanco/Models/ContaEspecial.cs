﻿namespace AplicativoBanco
{
    public class ContaEspecial : ContaBancaria
    {
        public double ValorLimite { get; set; }

        public ContaEspecial() { }

        public ContaEspecial(string nome, string conta, string agencia, double saldo, double limite)
            : base(nome, conta, agencia, saldo)
        {
            ValorLimite = limite;
        }

        public override bool Sacar(double valor)
        {
            if (valor <= 0) return false;

            if (Saldo - valor < -ValorLimite)
                return false;

            Saldo -= valor;
            return true;
        }
    }
}
