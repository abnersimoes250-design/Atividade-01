﻿using BancoProjeto;
using System;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BancoProjeto
{
    public class ContaEspecial : ContaBancaria
    {
        public double ValorLimite { get; set; }

        public ContaEspecial() { }

        public ContaEspecial(string nomeCliente, int numConta, string agencia, double saldo, double limite)
            : base(nomeCliente, numConta, agencia, saldo)
        {
            ValorLimite = limite;
        }

        public override void Sacar(double valor)
        {
            if (Saldo + ValorLimite >= valor)
            {
                Saldo -= valor;
                Console.WriteLine($"Saque de {valor:C} realizado (Conta Especial). Novo saldo: {Saldo:C}");
            }
            else
            {
                Console.WriteLine("Limite excedido!");
            }
        }
    }
}

