﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BancoProjeto
{
    public class ContaBancaria
    {
        public string NomeCliente { get; set; }
        public int NumConta { get; set; }
        public string Agencia { get; set; }
        public double Saldo { get; set; }

        public ContaBancaria() { }

        public ContaBancaria(string nomeCliente, int numConta, string agencia, double saldo)
        {
            NomeCliente = nomeCliente;
            NumConta = numConta;
            Agencia = agencia;
            Saldo = saldo;
        }

        public void Depositar(double valor)
        {
            Saldo += valor;
            Console.WriteLine($"Depósito de {valor:C} realizado. Novo saldo: {Saldo:C}");
        }

        public virtual void Sacar(double valor)
        {
            if (Saldo >= valor)
            {
                Saldo -= valor;
                Console.WriteLine($"Saque de {valor:C} realizado. Novo saldo: {Saldo:C}");
            }
            else
            {
                Console.WriteLine("Saldo insuficiente!");
            }
        }
    }
}

