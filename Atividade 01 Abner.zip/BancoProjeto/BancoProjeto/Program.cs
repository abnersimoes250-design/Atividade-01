﻿using BancoProjeto;
using System;

namespace BancoProjeto
{
    class Program
    {
        static void Main(string[] args)
        {
           
            ContaBancaria conta1 = new ContaBancaria("Roberto", 123, "0001", 1000);
            conta1.Depositar(200);
            conta1.Sacar(500);

            Console.WriteLine();

          
            ContaPoupanca poupanca = new ContaPoupanca("Rose", 456, "0002", 1500, 8, 0.05);
            poupanca.CalcularNovoSaldo(8); 
            poupanca.Sacar(300);

            Console.WriteLine();

         
            ContaEspecial especial = new ContaEspecial("João", 789, "0003", 500, 1000);
            especial.Sacar(1200); 
            especial.Depositar(400);

            Console.WriteLine();

           
            Console.WriteLine("Saldo final das contas");
            Console.WriteLine($"Conta normal - {conta1.NomeCliente}: {conta1.Saldo:C}");
            Console.WriteLine($"Poupança - {poupanca.NomeCliente}: {poupanca.Saldo:C}");
            Console.WriteLine($"Especial - {especial.NomeCliente}: {especial.Saldo:C}");

            Console.WriteLine("\nPressione qualquer tecla para sair...");
            Console.ReadKey();
        }
    }
}
