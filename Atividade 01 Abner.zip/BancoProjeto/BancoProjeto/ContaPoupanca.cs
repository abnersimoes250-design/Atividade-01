﻿using BancoProjeto;
using System;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BancoProjeto
{
    public class ContaPoupanca : ContaBancaria
    {
        public int DiaDeRendimento { get; set; }
        public double TaxaDeRendimento { get; set; }

        public ContaPoupanca() { }

        public ContaPoupanca(string nomeCliente, int numConta, string agencia, double saldo, int dia, double taxa)
            : base(nomeCliente, numConta, agencia, saldo)
        {
            DiaDeRendimento = dia;
            TaxaDeRendimento = taxa;
        }

        public void CalcularNovoSaldo(int diaAtual)
        {
            if (diaAtual == DiaDeRendimento)
            {
                Saldo += Saldo * TaxaDeRendimento;
                Console.WriteLine($"Rendimento aplicado! Novo saldo: {Saldo:C}");
            }
            else
            {
                Console.WriteLine("Hoje não é dia de rendimento.");
            }
        }
    }
}

